# Sufficient Statistics and Exchangeability

From <https://univ.ai/learning/sufstatexch/>

## Quick start

```bash
# Install uv (if you don't have it)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Run the notebook (installs dependencies automatically)
uvx juv run index.ipynb
```

`juv` reads the PEP 723 metadata inside the notebook and installs
the required packages into an isolated environment.

## Dependencies

- matplotlib
- numpy
- scipy
- seaborn

## License

Educational content from Univ.AI.
